package net.allesctf.allescraft.lobby;

public enum UserStates {
	PROOF_OF_WORK,
	QUEUE,
	FLAG,
	FIRST_BLOOD,
	STAFF
}
