package net.allesctf.allescraft.flag;

public enum ServerState {
	UNKNOWN,
	OFFLINE,
	STARTING,
	READY,
	IN_USE,
	FLAG_OBTAINED,
	SHUTTING_DOWN
}
