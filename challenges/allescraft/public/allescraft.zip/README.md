# how to install mc client

mc 1.12.2

install forge: http://files.minecraftforge.net/maven/net/minecraftforge/forge/index_1.12.2.html

select forge profile in minecraft launcher:
![klickibunti](https://i.imgur.com/pkz9mLp.png)

start once for .minecraft/mods

opencomputers: https://github.com/MightyPirates/OpenComputers/releases/download/v1.7.5/OpenComputers-MC1.12.2-1.7.5.192.jar

If you don't have a minecraft account and want to test your exploit contact staff on irc.
To test locally you can use a minecraft demo account, you will figure out a way to launch it ;)
To start the setup run `./run_service.py`
